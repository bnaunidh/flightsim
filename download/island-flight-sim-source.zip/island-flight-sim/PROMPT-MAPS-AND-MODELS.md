# Island Flight Simulator — the maps and the models

You are rebuilding two things in an existing game: **the thirty-two maps** and
**the eight aeroplanes**. Nothing else. The game around them works, is tested,
and is being played tomorrow by a class of twenty-nine ten-year-olds on school
Chromebooks and iPads, so the one thing worse than a dull island is a broken
one.

Read all of this before you write anything. The last third — **What has
already gone wrong** — is the part you cannot get from the code, and it is
where the previous four attempts at this job lost their time.

---

## 0. The rules. None of these are negotiable.

- **Three.js r169**, the copy already at `src/vendor/three.module.js`. Import
  it from there. One instance. No second copy, no other version.
- **Everything is procedural.** No model files, no texture images, no audio
  files, no CDN, no npm, no build step, no bundler. Textures are Canvas 2D,
  sound is Web Audio, terrain is a height function. The whole game is 1.3 MB
  and runs offline from a folder.
- **ES modules, served as files.** `import` paths are relative and real. A
  file that is not on disk at that path is a 404 and a black screen.
- **Axes: −Z is forward, +Y is up, +X is right.** Headings are compass
  degrees, and a heading `h` points along `(+sin h, 0, −cos h)`. Get this
  wrong and everything is mirrored; it has happened twice.
- **Metres, full size, scale 1.** A runway is 1,100 m because runways are.
- **30 fps on integrated graphics** is the budget. Assume a 2019 Chromebook.
- The audience is ten. If a thing needs explaining, it is wrong.

---

## 1. What the game is, in one screen

Four games share one world engine:

| game | maps | missions | vehicle |
|---|---|---|---|
| `flight` | 9 | 12 | eight aeroplanes |
| `boat` | 17 | 6 | launch / RIB |
| `car` | 9 | 6 | courier van |
| `heli` | 16 | 7 | one helicopter |

Thirty-two maps in `src/world/maps.js`, thirty-one missions in
`src/game/missions*.js`. A map may be listed under more than one game
(`games: ['boat', 'heli']`), which is why the columns add up to more than 32.

The terrain is **one analytic function**, `heightAt(x, z)` in
`src/world/terrain.js`. There is no heightmap and no mesh to author: the mesh
is sampled from the function. Everything a map declares — islands, harbours,
channels, shoals, roads, level ground — is a term in that function.

`heightAt` is called a few hundred times a frame for wheel and hull contact,
about ninety thousand times to build the terrain mesh, and 262,144 times to
draw one chart tile. Measured on an M-series Mac over a window full of
islands: **about 600 ns a sample**. Every term you add must reject on a
bounding box first. This is the single hardest constraint in the file.

---

## 2. PART ONE — THE MAPS

### 2.1 The schema, complete

This is Kestrel Island, the map everybody learns on. Every field below is real
and read by something.

```js
{
  id: 'kestrel',                     // referenced by missions and tests — DO NOT RENAME
  name: 'Kestrel Island',
  subtitle: 'Tropical · gentle hills',
  blurb: 'Warm, green and forgiving. Long runway, soft sea breeze…',
  difficulty: 1,                     // 1..5
  difficultyLabel: 'Gentle',
  game: 'flight',                    // which game owns it
  games: ['flight', 'boat'],         // optional: which games may borrow it
  seaFloor: -34,                     // the flat plate the islands stand on
  chartReach: 3800,                  // optional: how far the boat's chart draws

  islands: [
    { name: 'Kestrel Island', cx: 0, cz: 0, radius: 2450, peak: 300, seed: 3,
      profile: 'hills' },
    { name: 'Mango Cay', cx: 6200, cz: -5200, radius: 980, peak: 150, seed: 17,
      profile: 'hills' },
  ],

  // The terrain mesh is built in square chunks. One per island group, sized
  // to contain it. `segments` is the grid: 256 over 10,000 m is 39 m a quad,
  // which is the finest thing the ground can actually hold.
  chunks: [
    { cx: 0, cz: 0, size: 10000, segments: 256 },
    { cx: 6200, cz: -5200, size: 4600, segments: 128 },
  ],

  // The airfield. Omit it and the map inherits Kestrel's, which is wrong
  // everywhere else — see §4.4.
  airport: {
    elev: 12,
    headingDeg: 90,
    runway:  { cx: 0, cz: 0, length: 1100, halfWidth: 22 },
    runway2: { cx: 0, cz: 0, length: 900, halfWidth: 18, headingDeg: 180 },
    pad:     { x0: -700, x1: 700, z0: -260, z1: 260, blend: 200 },
  },

  waters: {
    // Two ways to place a harbour. Either give it coordinates, or give it an
    // island and a bearing and let the loader march out along that bearing
    // until the ground goes under water. The second is right for anything
    // whose coastline is made of noise.
    harbour: { island: 0, bearingDeg: 200, length: 250, width: 190,
               mouthWidth: 70, depth: 6, wallW: 26, quayW: 32, blend: 150,
               // optional: mouthDeg, cx, cz, wallY, quayY, shelf: false,
               //           shelfTop, shelfR
             },

    // A dredged lane. It only ever DEEPENS — see §4.2.
    channel: { halfWidth: 70, blend: 50, depth: 7,
               path: [[2323, 3318], [2019, 2883], [1749, 2498]] },

    // Banks, drying rocks, offshore stacks and coastal shelves are all the
    // same thing: a bump on the sea floor with a top you choose. `top` is an
    // ABSOLUTE height, not a rise, because what a chart and a depth gauge
    // care about is how much water is over it. Shelves go FIRST in the array;
    // each entry lifts from whatever the last one left, so a rock listed
    // after a shelf stands on the shelf.
    shoals: [
      { cx: 2600, cz: -2100, r: 760, top: -1.2 },
      { cx: -2650, cz: -3050, r: 300, top: 0.6, pow: 2.2, name: 'Needle Ledge' },
    ],

    // Authored roads. THREE NUMBERS PER POINT AND THE ORDER IS [x, z, y] —
    // ground plane first, elevation last. Not three.js order. See §4.5.
    roads: [
      { halfWidth: 26, blend: 55, name: 'The Waist',
        path: [[-1950, -40, 24], [-1600, -80, 22.8], [-1200, -120, 21.4]] },
    ],
  },

  // Authored level ground: yards, quays, village greens, hillside benches.
  // `elev: 'auto'` measures the middle 70% of the rectangle and levels to the
  // median, so you do not have to know a number you cannot know.
  flats: [
    { id: 'depot', name: 'Drover Depot', kind: 'depot', surface: 'tarmac',
      x0: 840, x1: 1060, z0: -295, z1: -125, elev: 'auto', blend: 100 },
    { id: 'quay', name: 'Ferry Hard', kind: 'harbour', surface: 'tarmac',
      x0: -1780, x1: -1360, z0: -700, z1: -520, elev: 4.5, blend: 95 },
  ],
  // kind: depot | harbour | town | village | relay | layby | causeway |
  //       quarry | apron       surface: tarmac | gravel | grass

  // The car game's addresses. The road router builds a network over these.
  courier: {
    depot: 'depot',
    places: [
      { id: 'depot', name: 'Drover Depot', x: 950, z: -210, kind: 'depot' },
      { id: 'quay',  name: 'Ferry Hard',  x: -1570, z: -610, kind: 'harbour',
        tidal: true },
      { id: 'rock',  name: 'Gull Skerry', x: -2500, z: -2200, boatOnly: true },
    ],
  },

  outpost: { cx: 6200, cz: -5200, elev: 'auto', minElev: 6,
             halfLen: 210, halfWidth: 55, blend: 150 },

  palette: {
    grass: [1.0, 1.0, 1.0],          // multipliers on the base palette
    sand:  [1.0, 1.0, 1.0],
    rock:  [1.0, 1.0, 1.0],
    deepWater: 0x123a5e,
    swell: 0x3a7ba8,
    shallow: [0.31, 0.84, 0.78],
    nightSky: 0x9fb8d8,
  },

  scenery: {
    pads: [                          // helipads. ids are referenced by missions
      { id: 'hospital', name: 'Kestrel Cottage Hospital', x: 760, z: 560,
        kind: 'roof', above: 30, r: 11 },
      { id: 'needle', name: 'Needle Rock', x: -2890, z: -3810,
        kind: 'stack', r: 9 },
    ],                               // kind: roof | stack | ground | deck
    coastTrees: 900, coastTreeHeight: 10,
    hillTrees: 600,  hillTreeHeight: 13,
    hillCentre: [200, 500], hillRadius: 1700, hillBand: [60, 260],
    town: { cx: 700, cz: 620, radius: 420, count: 46, minH: 16, maxH: 110 },
    lighthouse: [-3100, -3600],      // MUST be on land — see §4.3
    deliveryPad: [6200, -5200],
    boats: 3, padTrees: 280,
  },

  weather: { time: 'day', cond: 'clear', windSpeedKts: 6, windDirDeg: 250 },

  features: { reef: { islands: [0, 1], colour: 0x49d6c0, width: 0.22 } },
  // features: reef | volcano | waterfalls | fields | aurora

  // Optional per-map overrides of the approach corridors. Read §2.3 first.
  corridor:  { halfWidth: 380, blend: 320, fadeFrom: 3600, length: 5400 },
  corridor2: { halfWidth: 200, blend: 180, fadeFrom: 1500, length: 2400 },
}
```

### 2.2 The island profiles

Each island is a radial field. `profile` picks its character; `peak` is a
*scale*, not a measured summit — the terms overshoot it, typically by 1.3× to
1.6×, so check what you actually got.

| profile | character | what it is for |
|---|---|---|
| `flat` | a sandy cay barely out of the water, broad beaches | atolls, motus, bars |
| `plains` | wide and gentle, no ridge term, nothing steep anywhere | the maps you learn on, and every driving map |
| `hills` | rolling, a ridge term at moderate weight | the default island |
| `ridge` | steep and craggy, ridges running into the water | mountains, skerries, stacks |
| `cone` | a volcano: crater rim as the summit, a real bowl inside, fluted flanks | one island in the game, and it should stay that way |

`cone` takes `craterRadius` and `crater` (bowl depth) as well.

**Islands combine with `max()`,** so where two overlap the higher one wins and
then falls away over about 140 m. A tall island beside a low one is therefore
not a saddle, it is a cliff. This cost the Cape Vessel map three of its seven
addresses; see §4.1.

### 2.3 The approach corridor, and why it is the most dangerous system here

Every map with a runway gets a lane of cleared ground off each end so the
approach is not into a hillside. It is applied inside `heightAt`.

```
APPROACH_SLOPE       0.12    the ceiling's climb-out gradient, per metre out
APPROACH_SIDE_SLOPE  0.35    the ceiling's climb SIDEWAYS from the centreline
MAX_APPROACH_CUT     260 m   the deepest a corridor may cut
CORRIDOR             halfWidth 380, blend 320, fadeFrom 3600, length 5400
CORRIDOR2            halfWidth 200, blend 180, fadeFrom 1500, length 2400
```

It used to hold one flat ceiling — field elevation plus ten metres — for five
and a half kilometres, in a band nearly a mile wide, in both directions, on
islands 2.4 km across. That is not a corridor, it is a cross bulldozed through
the map, and **thirty of the thirty-two maps had one.** Measured: 46% of
Kestrel's land cut, by up to 345 m. It is invisible from the cockpit on final,
which is the only place anybody ever looked.

It is now a valley with sides: the ceiling rises at 12% along the lane and 35%
away from the centreline, the lane's width and floor wander instead of running
dead straight, and the second corridor — for a runway nobody flies — is a
fifth of the size it was. Kestrel is down to 23%, Fjord from 42% to 7%, the
Rigs from 45% to 16%.

**What this means for you:** if your map needs a big corridor cut to be
flyable, the map is wrong, not the corridor. Put the runway on ground that
does not need carving. Measure it — the tool is in §5 and it prints the
percentage.

### 2.4 Roads, for the driving maps

`src/world/roads.js` builds a network over `courier.places` as a minimum
spanning tree, routing each link with Dijkstra over a height grid.

```
CELL           90 m   the routing grid
HARD_MAX       0.38   a cell steeper than this is not a road at any price
GRADE_PENALTY  9      cost = length × (1 + 9 · (grade/MAX_GRADE)²)
MAX_GRADE      0.10   what the finished profile is eased to
STEP           55 m   sample spacing along the finished road
halfWidth      18 m   graded corridor half-width (the tarmac is narrower)
maxFill        30 m   refuse a link that needs a taller embankment
maxCut         45 m   refuse a link that needs a deeper cutting
```

It also refuses to route through a building: the obstacle boxes the aeroplane
can crash into are the same boxes the road goes round. And when a link is
about to be refused it retries once on a half-size grid at a 13% gate, which
is what produces switchbacks.

**A driving map should be built flat on purpose.** Kestrel is a mountain with
one flat band through its waist, and that band is the only drivable ground on
it: a route along it needs a 0.9% grade and 4.6 m of cut, while the obvious
route up to the town needs 27% grades and a 104 m embankment. Do not carve a
car map out of a mountain.

### 2.5 What makes a good map, concretely

- **Relief you can see.** Measured standard deviation of land height over the
  main island, sampled on a 48×48 grid inside 85% of the radius: Redrock
  Flats was **3.8 m across five and a half kilometres** — a billiard cloth
  with the longest drive in the game over it. It is 9.7 m now and that is
  still flat country. Under about 8 m and the eye has nothing to hold.
- **Nothing drawn with a compass.** The Coral Lagoon's reef was sixty
  identical circles on a perfect ring. The Archipelago had nine identical
  shoals in a straight line. Longbank and the Skerries had a pale blue disc
  of an approach shelf with an edge you could see from three thousand feet.
  Ember's volcano had thirteen evenly spaced flutes, which from above is a
  dartboard. If you generate a feature in a loop, vary radius, height, spacing
  and phase, and use rates that do not divide into each other.
- **Somewhere to go.** A map is a set of destinations with different
  characters and a reason to cross between them. Nine places all on the same
  plain is one place.
- **One idea per map.** "A reef ring with two passes, one buoyed and one not."
  "A chain of five islands and a road down the spine." "A fjord with the strip
  on the valley floor." If you cannot say it in a sentence, the map has not
  been designed.

---

## 3. PART TWO — THE MODELS

### 3.1 Where each aeroplane is actually drawn. Read this twice.

There are **two** model systems, and the wrong guess costs a day.

```js
// src/aircraft/model-adapter.js
const PACK_DRAWS_BETTER = new Set(['vanguard', 'osprey', 'nightjar']);
```

- **vanguard, osprey, nightjar** → `src/fleet/aircraft-combat.js`, built by
  `buildAircraft()` in `src/fleet/aircraft-core.js`. Hand-built geometry:
  panels, tubes, boxes, lofted skins.
- **skylark, courier, meridian, tempest, harrier** → `src/aircraft/model.js`,
  built from the `shape` block in `src/aircraft/types.js`. One lofted fuselage
  and one aerofoil wing, parameterised.

Both go through `createAircraftModel()` in `model-adapter.js`, which is the
call `main.js` makes. **Measure through that call, not through either system
directly.** The Nightjar took two days because the shape being measured was
not the shape being drawn.

Current, measured through the adapter:

| id | name | class | meshes | triangles |
|---|---|---|---|---|
| skylark | Skylark 172 | Trainer | 63 | 5,066 |
| courier | Kestrel Courier | Tourer | 39 | 3,914 |
| meridian | Meridian 220 | Airliner | 42 | 4,682 |
| tempest | Tempest WR-4 | Tourer | 45 | 4,084 |
| harrier | Skyhook H-3 | Helicopter | 46 | 4,358 |
| vanguard | Vanguard F-1 | Fighter | 43 | 1,526 |
| osprey | Osprey CV | Carrier | 51 | 1,698 |
| nightjar | Nightjar B-2 | Fighter | 39 | 1,032 |

Four to five thousand triangles is the working budget. The fleet three are
cheaper because they are panelled rather than lofted; that is a fair trade,
not a target.

### 3.2 Schema A — the parameterised aeroplanes (`src/aircraft/types.js`)

```js
const TRAINER_SHAPE = {
  scale: 1,
  bodyLength: 1, bodyRadius: 1,     // multipliers on the shared lathe profile
  halfSpan: 5.52,                   // centreline to tip
  rootChord: 1.68, tipChord: 1.02,
  sweep: 0.28,                      // how far aft the tip sits
  dihedral: 0.23,                   // how far up
  wingY: 0.72, wingZ: -1.05, wingRootX: 0.62,
  struts: true,
  hSpan: 1.75, hRootChord: 1.0, hZ: 2.85,
  finHeight: 1.55, finRootChord: 1.5, finSweep: 0.62, finZ: 2.55,
  power: { kind: 'prop', count: 1, propRadius: 1.05, z: -2.6 },
  //      kind: 'prop' | 'jet';  rotor: true makes it a helicopter
  canopy: 'cabin',                  // cabin | greenhouse | bubble | airliner | wing
  hook: false,
  eye: [-0.24, 0.46, 0.06],         // the camera rig reads this
  nose: { x: 0, y: -1.42, z: -1.15 },
  main: { x: 1.42, y: -1.5, z: 0.42 },
  wheelR: { nose: 0.3, main: 0.36 },
  gearStiffness: 1, retractable: false,
};
```

`nose` / `main` are **ground contact points the flight model uses verbatim**.
Move the gear and you move where the aeroplane sits; get them wrong and it
noses in on touchdown. The strike points used by the damage model are derived
from the same numbers, so the drawn aeroplane and the flown one always agree.

Per-aeroplane detail that does not belong in the shared builder goes in its
own module — `src/aircraft/models/skylark.js` is the pattern. No imports, a
pure function library taking `THREE` and the already-built materials as
arguments, and one `install<Name>Details(ctx)` entry that is a no-op for every
other aeroplane.

### 3.3 Schema B — the hand-built aeroplanes (`src/fleet/aircraft-*.js`)

```js
const vanguard = {
  id: 'vanguard', name: 'Vanguard F-1', kind: 'fighter', massKg: 7200,
  paint: '#737b83', accent: '#344454', registration: 'VF-101',
  bodySegments: 12,
  // Lathe stations: [z, radiusY, radiusX, yOffset]
  body: [[-7.1,.025,.035,-.02], [-5.5,.41,.38,0], [-.3,.72,.60,-.025],
         [6.4,.43,.43,-.05]],
  wing: { rootX:.62, span:4.33, rootZ:-1.8, rootY:-.12, rootChord:4.8,
          tipChord:1.2, sweep:3.6, dihedral:-.10, thickness:.17,
          tipThickness:.045, flaps:true, struts:false },
  tail: { … }, fin: { … },
  canopy: { kind:'bubble', z0:-4.55, z1:-1.28, width:.56, height:.59, baseY:.21 },
  gear: { nose:[0,-1.62,-3.48], main:[1.27,-1.65,.91], noseRadius:.25,
          mainRadius:.32, retractable:true, dualMain:false, doors:true },
  engines: [{ id:'engine', kind:'jet', x:0, y:-.05, z:5.1, radius:.435,
              length:2.5, buried:true, afterburner:true }],
  eye: [0,.65,-3.1], hook: false,
  decorate(ctx) { … },
  description: '…',
  inspiration: 'Original aircraft using coherent single-engine fighter proportions; not a licensed replica.',
};
```

`decorate(ctx)` is where the character goes. `ctx` gives you:

```js
{ model, config, materials, parts, group, box, tube, panel, skin,
  registerAnimation, THREE }

group(id, label, massKg, dependsOn, parent)   // a named, damageable section
box(name, [w,h,d], [x,y,z], mat, parent)
tube(name, a, b, radius, mat, parent, segments)
panel(name, [p0,p1,p2,p3], mat, parent)       // exactly four corners
skin(stations, mat, parent, radial)           // a lofted shell
```

Materials, already built and lit for the scene's environment map:

```
skin  wing  tail  accent  metal  dark  rubber  glass  interior  light  hot
```

**Use them.** The game builds a PMREM of its own procedural sky every time the
weather or the time of day changes, so anything with `metalness > 0` gets a
bright band along the top of the fuselage and a darker one underneath, both
moving as you roll. Matte materials get none of it and read as coloured
plastic. That is the single reason the previous civil pack lost to the
built-in aeroplanes.

### 3.4 What makes a good aeroplane here

- **The planform is the aeroplane.** Four things read as "B-2" at three
  hundred metres: a huge span with no fuselage, one unbroken knife leading
  edge, no vertical surface anywhere, and the sawtooth trailing edge. The
  model had three of the four, and the trailing edge measured 3.50, 3.50,
  1.86, 3.13, 3.13, 6.65 — one shallow step with two flat pairs either side,
  which from above is a bevel, not a saw. Fixing six numbers fixed the
  aeroplane, at zero cost in triangles. **Get the outline right before you add
  anything.**
- **Proportion against the real thing.** The Nightjar's span:length is
  33.5/13.05 = 2.57, against the real B-2's 52.4/21 = 2.5. Quote a number like
  that for every aeroplane you touch.
- **Originals, not replicas.** Coherent proportions from the class of
  aircraft, given the game's own names and registrations. Say so in
  `inspiration`.
- **Detail where a ten-year-old looks:** the nose, the canopy, the gear, the
  engine. Nobody has ever looked at the underside of the tailplane.

---

## 4. What has already gone wrong. Do not do these again.

Every one of these was found by measurement, cost hours, and is invisible in
code review.

### 4.1 A tall island next to a low one is a cliff, not a saddle

Cape Vessel is a chain of five islands. Three of its seven addresses had no
road and no road could be built to them. It was not a router bug:
flood-filling the router's own rules from the depot walls in at x=1760, and it
takes a **65% gate — a thirty-three degree slope** — to reach the relay. Two
'ridge' islands at peak 190 and 230 measured 303 m on the ground; they are
'hills' at 150 and 180 now and the cape tops out at 198 m. Separately, High
Vessel at 140 beside Vessel Point at 90 produced a **65 m step in one grid
cell**, the road came down at its 10% and floated 54 m over the drop, and the
link was refused.

**Check every island against its neighbours, and check the saddle between
them, not the peaks.**

### 4.2 A channel only ever deepens

Writing the floor to −7 unconditionally would build a shallow **bar** down the
middle of the approach on every map whose sea floor is deeper than that — and
they run −22 to −60. The test is `if (h > floor)`. A dredged channel is worth
having only on a map that has a shelf to cut it into.

### 4.3 Things that must be on the ground they claim

Nine lighthouses were under water. Four towns had no buildings in them,
because the height band they scattered into did not exist on that island. A
runway was up a mountain. Two maps threw inside `new Scenery()` and came up
black. **Every coordinate you write has to be checked against `heightAt` at
that coordinate.**

### 4.4 Coordinates copied between maps

`apron` was at `(-80, -148)` on every courier map. Four of them put their
strip at the origin so it happened to land on the pad; Airfield Perimeter
sites its 450 m strip at `(-582, 801)`, so its apron address was a kilometre
away in open country with no road to it. Similarly, `RUNWAY_START` was fixed
at Kestrel's runway and **fourteen maps spawned the player inside a hill.**

### 4.5 `[x, z, y]`, ground plane first, elevation last

Every reader of a road path — `roadHeight`, `onRoad`, `roadRibbon`,
`nearestRoadPoint`, the chart — takes `[0]` and `[1]` as the map coordinates
and `[2]` as the height. A path written in three.js order is self-consistent
enough that nothing throws. It just puts the road somewhere else and cuts a
trench along it. One map had a 1,500 m spike in it for this reason.

### 4.6 The road did not know the buildings were there

The Drover's Flat depot→airfield road ran straight through the terminal. The
van reached waypoint 20 of 23 and stopped dead against the wall: 425 m in 420
seconds, with the control tower and the terminal inside 120 m of where it
stood. The router was routing over an obstacle list that had just been
emptied. **Order matters:** the airfield registers its boxes, then the roads
are laid, then the terrain mesh is built — because `roadHeight` is part of
`heightAt`, so the mesh must come after the paths exist.

### 4.7 `node --check` is not enough

It parses an ES module as a script and misses every link-time error. A file
that "passes" can still take the whole game down on import. **Actually
`import()` the module.**

### 4.8 Module caching will lie to you

Cache-busting the HTML does not bust the module URLs. Serve on a **fresh
port** for every verification round, or you will spend an hour measuring code
you already changed.

### 4.9 Anything you add must be in the offline cache

`sw.js` has a hand-written precache list. Twenty-one modules had fallen off
it — every HUD but the aeroplane's, the job board, the boat and helicopter
missions, the roads, the pads, the seamarks, the game switcher. Online it
never showed. Install the game on an iPad, walk out of range, pick anything
but Flight, and it was a 503. **Every new file goes in `PRECACHE` and
`CACHE_VERSION` gets bumped.**

### 4.10 The suite appears to hang in a window that is not on screen

`sim.step()` renders a frame per step, and a tab that is not compositing never
finishes one. Stub it: `window.__sim.renderer.render = () => {}`. The suite
never reads a pixel, and the run goes from over an hour to forty seconds.

---

## 5. How to verify, before you send anything

The project's rule is that a fault you can see in a picture should never be
found by argument. These tools exist; use them and paste what they print.

```bash
# Every map's height field, as plain JSON grids.
node tools/heightfield.mjs --all /tmp/hf

# All thirty-two on one page: shaded relief with the runway, roads, pads,
# harbour, buoyage, drying shoals and named places drawn over it.
python3 tools/mapsheet.py /tmp/hf /tmp/sheet.png

# The same grids as a mesh you can orbit. Heights are exaggerated 2.5× by
# default — check at vscale 1.0 before you decide a mountain is too spiky.
#   import blender_terrain as bt; bt.load_all('/tmp/hf')

# Every aeroplane's triangles, through the adapter the game uses.
node tools/silhouette.mjs --all /tmp/sil
python3 tools/planview.py /tmp/sil /tmp/fleet.png      # plan, side, front
```

And the suite, which is **146 checks** and has to stay at 146:

```js
window.__sim.renderer.render = () => {};               // see §4.10
const { runSelfTest } = await import('./tests/selftest.js');
const r = await runSelfTest(window.__sim);
console.log(r.summary, r.checks.filter(c => !c.pass));
```

Among other things it asserts, for every map: the runway is at field
elevation along its whole length, every harbour has 3 m under the keel at the
quay and at the mouth, every shoal marked as drying really dries, the buoyage
marks the lane it is derived from, every courier place has tarmac within
220 m, every road point reads as being on its own road, and every module the
game loaded is in the offline cache.

**Send measurements, not adjectives.** "Peak 300 measured 341 m on the ground,
sea floor −34, worst local grade 0.42 at (1200, −380)" is a review. "Dramatic
and rugged" is not.

---

## 6. What to actually fix, in order

These are open, measured, and known. Anything else you improve is a bonus.

1. **Kestrel still has 23% of its land cut by the approach corridors, 288 m at
   the worst point.** The island is 2.4 km across with the runway in the
   middle and a 278 m hill a kilometre off the threshold. The corridor is
   doing its job; the map is asking too much of it. Re-site the field, or
   reshape the island around the field, so the lane costs nothing. This is the
   most-played map in the game.
2. **Four islands are too flat to be interesting**, and low relief is not
   their point the way it is a sandy cay's. Measured standard deviation of
   land height over the main island, on a 48×48 grid inside 85% of the
   radius: Ravencrag 5.2 m, Meridian 6.4 m, Town 6.5 m, Airfield Perimeter
   8.9 m. Two of those are helicopter maps whose whole point is looking at
   the ground. (The Atoll at 3.4 m and the Delta at 2.7 m are `flat` cays and
   a river mouth; those are meant to be low.)
3. **Town's street grid is a mechanical lattice** and the Delta's shoals are
   two straight columns.
4. **The Stacks' central island is a ring** rather than the flat rock it is
   named for.
5. **The Courier, the Meridian, the Tempest and the Skyhook still take the
   generic parts** from the shared builder: square wingtips, no root fairings,
   a lathe fuselage doing duty as an airliner. The Skylark shows what a
   per-aeroplane detail module looks like.
6. **Nothing has a cockpit worth looking into** except through glass that is
   mostly opacity.

---

## 7. What to send back

- **Whole files**, complete, in the tree's own layout. Not diffs, not
  fragments, not "add this after line 451".
- For each file, a header comment saying what changed, **with the numbers you
  measured before and after**, and what you could not check.
- The contact sheet and the three-views as images, or the numbers from them.
- A list of anything you changed that another file reads — map ids, place ids,
  pad ids, mission-facing names — because those are referenced by
  `src/game/missions*.js` and by the test suite. The missions name these maps
  and they must keep existing: `airbase ember kestrel kestrel-port longbank
  rigs sennen skerries stacks`.
- The suite's summary line.

If something in this document is wrong, say so and say how you measured it.
Twice now the brief has described an aeroplane the codebase does not contain,
and both times the right move was to flag it rather than build to the brief.
